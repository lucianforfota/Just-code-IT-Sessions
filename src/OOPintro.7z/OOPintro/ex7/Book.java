package OOPintro.ex7;

public class Book {

    String title;
    int numberOfPages;
    int weight;

    public Book(String title, int numberOfPages, int weight) {
        this.title = title;
        this.numberOfPages = numberOfPages;
        this.weight = weight;
    }
}
