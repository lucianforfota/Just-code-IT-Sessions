package OOPintro.ex3;

public class Main {
    public static void main(String[] args) {
        Cat cat1 = new Cat("1");

        Cat cat2 = new Cat("2");
        System.out.println(Cat.counter);





    }
}
