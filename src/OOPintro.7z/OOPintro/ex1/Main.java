package OOPintro.ex1;

public class Main {

    public static void main(String[] args) {
        Dog dog1 = new Dog("a","b","c");
        Dog dog2 = new Dog("x","y","z");
        dog1.bark();
        dog1.run();
        dog2.bark();
        dog2.run();
    }
}
